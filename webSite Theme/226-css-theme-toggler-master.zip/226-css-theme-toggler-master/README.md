# Light/Dark/Solar Mode Theme Toggler

[Dynamic theme-toggler tutorial](https://youtu.be/rXuHGLzSmSE) with CSS Variables and JavaScript.  


All see [CSS Variables in 100 Seconds](https://youtu.be/NtRmIp4eMjs). 
